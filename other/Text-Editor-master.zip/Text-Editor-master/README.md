# Text Editor
A rich text editor implemented in Python using Tkinter

![text-editor-photo](/text-editor.png)

## Running Text Editor
Requires Python and Tkinter, os, PIL modules. Once the modules are installed you can run the editor using
```
  $ python main.py
```
